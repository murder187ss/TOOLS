﻿namespace GitHub.Authentication.ViewModels.Validation
{
    public enum ValidationStatus
    {
        Unvalidated = 0,
        Invalid = 1,
        Valid = 2,
    }
}
