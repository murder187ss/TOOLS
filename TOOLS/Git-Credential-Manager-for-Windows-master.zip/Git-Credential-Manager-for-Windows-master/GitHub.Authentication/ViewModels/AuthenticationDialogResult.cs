﻿namespace GitHub.Authentication.ViewModels
{
    public enum AuthenticationDialogResult
    {
        None,
        Ok,
        Cancel
    }
}
